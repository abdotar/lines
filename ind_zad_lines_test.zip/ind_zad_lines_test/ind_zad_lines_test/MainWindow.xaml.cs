﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace ind_zad_lines_test
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        public int gamestatus = 0;
        public int [][] gamemass;
        public int ballcount;
        public int addingballs;
        public int xx;
        public Ellipse ball;
        public int ballx;
        public int bally;
        public int fieldx;
        public int fieldy;
        public bool ballispresed;
        public bool canpressball;
        public int curentballcolor;
        public int ballchidindex;
        public int[][] movemass;
        public int[][] indexbalmass;
        public Rectangle b;
        public Ellipse curentball;
        public bool balscleared;
        public int score1;
        int n;
        int m;
        public bool thereisway;
        public int  startdelx,startdely,enddelx,enddely;//откудо удалять
        public MainWindow()
        {
            InitializeComponent();

        }



        private void exit(object sender, RoutedEventArgs e)
        {
            Close();
        }
        public void addbals(int num,int method)//если метод 0 то рандом если метод 1 то с параметрами
    {
        int ballcounter =0;
        int nn;
        int mm;
        while (ballcounter < num)
        {
            int ballinmas = 0;
            ball = new Ellipse();
            Random rand = new Random();
            Thickness th = new Thickness(4);
            this.ball.Margin = th;
            if (method == 1)
            {
                nn = fieldx;
                mm = fieldy;
                xx = curentballcolor;
                Grid.SetColumn(ball, nn);
                Grid.SetRow(ball, mm);
                if (xx == 1)
                {
                    ball.Fill = new SolidColorBrush(Colors.Red);
                    ballinmas = 1;
                }

                if (xx == 2)
                {
                    ball.Fill = new SolidColorBrush(Colors.Orange);
                    ballinmas = 2;
                }

                if (xx == 3)
                {
                    ball.Fill = new SolidColorBrush(Colors.Yellow);
                    ballinmas = 3;
                }
                if (xx == 4)
                {
                    ball.Fill = new SolidColorBrush(Colors.Green);
                    ballinmas = 4;
                }
                if (xx == 5)
                {
                    ball.Fill = new SolidColorBrush(Colors.Aqua);
                    ballinmas = 5;
                }

                if (xx == 6)
                {
                    ball.Fill = new SolidColorBrush(Colors.Purple);
                    ballinmas = 6;
                }

                if (xx == 7)
                {
                    ball.Fill = new SolidColorBrush(Colors.Blue);
                    ballinmas = 7;
                }
                if (gamemass[nn][mm] == 0 && ballinmas != 0)
                {

                    ball.MouseLeftButtonDown += new MouseButtonEventHandler(selecevent);

                    this.gamemass[nn][mm] = ballinmas;
                    circulefield.Children.Add(ball);
                    this.indexbalmass[nn][mm] = circulefield.Children.IndexOf(ball);
                    ballcounter++;

                }
            }
            else 
            { 
            nn = rand.Next(0, n);
            mm = rand.Next(0, m);
            Grid.SetColumn(ball, nn);
            Grid.SetRow(ball, mm);
            this.xx = rand.Next(1, 7);
            if (xx == 1)
            {
                this.ball.Fill = new SolidColorBrush(Colors.Red);
                ballinmas = 1;
            }

            if (xx == 2)
            {
                this.ball.Fill = new SolidColorBrush(Colors.Orange);
                ballinmas = 2;
            }

            if (xx == 3)
            {
                this.ball.Fill = new SolidColorBrush(Colors.Yellow);
                ballinmas = 3;
            }
            if (xx == 4)
            {
                this.ball.Fill = new SolidColorBrush(Colors.Green);
                ballinmas = 4;
            }
            if (xx == 5)
            {
                ball.Fill = new SolidColorBrush(Colors.Aqua);
                ballinmas = 5;
            }

            if (xx == 6)
            {
                ball.Fill = new SolidColorBrush(Colors.Purple);
                ballinmas = 6;
            }

            if (xx == 7)
            {
                ball.Fill = new SolidColorBrush(Colors.Blue);
                ballinmas = 7;
            }
            if (gamemass[nn][mm] == 0 && ballinmas != 0)
            {

                ball.MouseLeftButtonDown += new MouseButtonEventHandler(selecevent);

                this.gamemass[nn][mm] = ballinmas;
                circulefield.Children.Add(ball);
                this.indexbalmass[nn][mm] = circulefield.Children.IndexOf(ball);
                ballcounter++;
            }

            }
        }

    }
        private void Start_game(object sender, RoutedEventArgs e)
        {

            if (gamestatus == 0)
            {
                
                gamestatus = 1;
                main_menu.Visibility = System.Windows.Visibility.Collapsed;
                option_menu.Visibility = System.Windows.Visibility.Collapsed;
                scorepanel.Visibility = System.Windows.Visibility.Visible;

                this.n = Convert.ToInt32(tb1.Text);
                this.m = Convert.ToInt32(htb.Text);
                field f = new field(n, m, field1, fieldwin, 1);
                f.addrowsandcol();
                for (int i = 0; i < n; i++){
                for (int j = 0; j < m; j++)
                {
                    this.b = new Rectangle();
                    b.Fill = new SolidColorBrush(Colors.Gray);
                    Thickness th = new Thickness(1);
                    b.Margin = th;
                    b.MouseLeftButtonDown += new MouseButtonEventHandler(clickrec);

                    Grid.SetRow(b, j);
                    Grid.SetColumn(b, i);
                    field1.Children.Add(b);
                }
                }
                   
                field c = new field(n, m, circulefield, fieldwin, 1);
                c.addrowsandcol();
                gamemass = new int[n][];
                indexbalmass = new int [n][];
                for (int i = 0; i < n; i++)
                {
                    gamemass[i] = new int[m];
                    indexbalmass[i] = new int[m];
                }
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < m; j++)
                    {
                        this.gamemass[i][j] = 0;
                        this.indexbalmass[i][j] = -1;
                    }
                }
                
                

                this.addingballs = 3;
                
                
                addbals(addingballs,0);
                this.balscleared = false;
            }
            
            else
            {
                main_menu.Visibility = System.Windows.Visibility.Collapsed;
                option_menu.Visibility = System.Windows.Visibility.Collapsed;
                scorepanel.Visibility = System.Windows.Visibility.Visible;
                fieldwin.Visibility = System.Windows.Visibility.Visible;
            }

        }

        public void chekcolortoremovevertical()
        {
            int counter = 1;
            int finder;
            this.startdelx = 0;
            this.startdely = 0;
            this.enddely = 0;
            this.enddely = 0;
            for (int i = 0; i < n; i++)
            {
                finder = gamemass[i][0];
                this.startdelx=i;
                this.startdely =0;
                counter = 0;
                for (int j = 0; j < m; j++)
                {
                    if (gamemass[i][j] == finder && finder !=0 )
                    {

                        counter++;
                        if (j + 1 == m)
                        {
                            this.enddelx = i;
                            this.enddely = j+1;
                            if (counter >= 5)
                            {
                                removeballsinrow(startdelx, startdely, enddely);
                                this.score1 = score1 + counter;
                                score.Content = Convert.ToString(score1);
                                counter = 0;
                            }
                        }
                    }
                    else
                    {
                        if (gamemass[i][j] != 0) 
                        {
                            finder = gamemass[i][j];
                        }
                        this.enddelx = i;
                        this.enddely = j;
                        
                        if(counter >= 5)
                        {
                            removeballsinrow(startdelx, startdely, enddely);
                            this.score1 = score1 + counter;
                            score.Content = Convert.ToString(score1);
                            counter = 0;
                        }
                        else
                        {
                            this.startdelx =i;
                            this.startdely =j;
                            counter=1;
                            finder = gamemass[i][j];
                        }

                    }
                        


                }
                
            }
        }
        public void chekcolorremovehorizontal()
        {
            int counter = 1;
            int finder;
            this.startdelx = 0;
            this.startdely = 0;
            this.enddely = 0;
            this.enddely = 0;
            for (int i = 0; i < m; i++)
            {
                finder = gamemass[0][i];
                this.startdelx = 0;
                this.startdely = i;
                counter = 0;
                for (int j = 0; j < n; j++)
                {
                    if (gamemass[j][i] == finder && finder != 0)
                    {

                        counter++;
                        if (j + 1 == n)
                        {
                            this.enddelx = j + 1;
                            this.enddely = i;
                            if (counter >= 5)
                            {
                                removeballsinline(startdely, startdelx, enddelx);
                                this.score1 = score1 + counter;
                                score.Content = Convert.ToString(score1);
                                counter = 0;
                            }
                        }

                    }
                    else
                    {
                        this.enddelx = j;
                        this.enddely = i;


                        if (counter >= 5)
                        {
                            removeballsinline(startdely, startdelx, enddelx);
                            this.score1 = score1 + counter;
                            score.Content = Convert.ToString(score1);
                            counter = 0;
                        }
                        else
                        {
                            if (gamemass[j][i] != 0)
                            {
                                finder = gamemass[j][i];
                            }
                            this.startdelx = j;
                            this.startdely = i;
                            counter = 1;
                            
                        }

                    }



                }

            }

        }

        public void removeballsinrow(int startx , int starty , int endy)
        {
                for(int j = starty ; j< endy ;j ++)
                {
                    int bs = gamemass[startx][j];
                    //circulefield.Children.RemoveAt(indexbalmass[startx][j]);
                    this.indexbalmass[startx][j] = -1;
                    this.gamemass[startx][j] = 0;
                }
                this.balscleared = true;
            
        }
        public void removeballsinline(int starty, int startx, int endx)
        {
            for (int j = startx; j < endx ; j++)
            {
                int bs = gamemass[j][starty];
                this.gamemass[j][starty] = 0;
                
            }
            this.balscleared = true;

        }
        public void updatefield()
        {
            circulefield.Children.Clear();
            this.ballcount = 0;
            for(int i = 0; i<n ; i++)
            {
                for(int j = 0; j< m ; j++)
                {
                    
                    Ellipse ball = new Ellipse();
                    Thickness th = new Thickness(4);
                    ball.Margin = th;
                    ball.MouseLeftButtonDown += new MouseButtonEventHandler(selecevent);
                    if(gamemass[i][j] != 0)
                    {
                        if (gamemass[i][j] == 1)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Red);
                        }

                        if (gamemass[i][j]==2)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Orange);
                        }

                        if (gamemass[i][j] == 3)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Yellow);
                            
                        }
                        if (gamemass[i][j] == 4)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Green);
                            
                        }
                        if (gamemass[i][j] == 5)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Aqua);
                            
                        }

                        if (gamemass[i][j] == 6)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Purple);
                            
                        }

                        if (gamemass[i][j] == 7)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Blue);
                            
                        }

                        Grid.SetColumn(ball, i);
                        Grid.SetRow(ball, j);
                        circulefield.Children.Add(ball);
                        this.ballcount++;
                    }

                }
            }
            
        }


        private void howtoplay(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Правила простые :\nЦель игры набрать как можно больше очков\nОчки набираются методом складываня 5 или более шариков 1-го цвета в ряд по горизонтали или вертикали\nчтобы передвинуть шарик надо на него нажать леввой кнопкой мыши\nзатем нажать на поле куда передвинуть шарик\nесли прохода к нужному полю нет то шар нельзя переместить.\nКогда собрали 5 или более шариков то нове шарики не появляются\nПриятной игры )))");

        }


        private void options(object sender, RoutedEventArgs e)
        {
            if (gamestatus == 0)
            {
                gameover.Visibility = System.Windows.Visibility.Collapsed;
                main_menu.Visibility = System.Windows.Visibility.Collapsed;
                scorepanel.Visibility = System.Windows.Visibility.Collapsed;
                fieldwin.Visibility = System.Windows.Visibility.Collapsed;
                option_menu.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                var result = MessageBox.Show("хотите закончить игру ?", " ", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    gamestatus = 0;
                    field g = new field(field1);
                    field c = new field(circulefield);
                    g.resetfield();
                    c.resetfield();
                    scorepanel.Visibility = System.Windows.Visibility.Collapsed;
                    fieldwin.Visibility = System.Windows.Visibility.Collapsed;
                    option_menu.Visibility = System.Windows.Visibility.Visible;
                    main_menu.Visibility = System.Windows.Visibility.Collapsed;

                }
            }
        }


        private void aboutme(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("разработал : Тарраб Абдул Рахман Омар");
        }

        public void selecevent(object sender, EventArgs e)
        {


            Ellipse ball = (Ellipse)sender;
            this.ballispresed = true;
            this.canpressball = true;
            this.balscleared = false;
            this.ballchidindex = circulefield.Children.IndexOf(ball);
            this.ballx = Grid.GetColumn(ball);
            this.bally = Grid.GetRow(ball);
            this.curentballcolor = gamemass[Grid.GetColumn(ball)][Grid.GetRow(ball)];
            
            

        }

        public void findway() 
        {
            int d=1;
            
             movemass = new int[n][];
                for (int i = 0; i < n; i++)
                {
                    movemass[i] = new int[m];
                }
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < m; j++)
                    {
                        if (gamemass[i][j] == 0)
                        {
                            this.movemass[i][j] = 0;
                        }
                        else
                        {
                            this.movemass[i][j] = -1;
                        }
                    }
                }
                movemass[ballx][bally] = d;
                int asd = movemass[fieldx][fieldy];

                while (movemass[fieldx][fieldy] == 0 && d < (m * n)) 
                {
                    for (int i = 0; i < n; i++)
                    {
                        for (int j = 0; j < m; j++)
                        {
                            if (movemass[i][j] == d)
                            {
                                if (i + 1 < n)
                                {
                                    if (movemass[i + 1][j] == 0)
                                    movemass[i + 1][j] = d + 1;
                                }
                                if (j + 1 < m)
                                {
                                    if (movemass[i][j+1] == 0)
                                    movemass[i][j + 1] = d + 1;
                                }
                                if (j - 1 >= 0)
                                {
                                    if (movemass[i][j-1] == 0)
                                    movemass[i][j - 1] = d + 1;
                                }
                                if (i - 1 >= 0)
                                {
                                    if (movemass[i - 1][j] == 0)
                                    movemass[i - 1][j] = d + 1;
                                }
                               

                            }

                        }
                    }
                    d = d + 1;
                }

                int cheker = 0;

                if (movemass[fieldx][fieldy] != 0) 
                {
                    
                            this.thereisway = true; 
                        }

                    
                    
                
                else
                {
                    this.thereisway = false;

                }
        }

        public void clickrec(object sender, EventArgs e)
        {


            Rectangle rec = (Rectangle)sender;

            if (canpressball) 
            {
                this.fieldx = Grid.GetColumn(rec);
                this.fieldy = Grid.GetRow(rec);
                if (gamemass[fieldx][fieldy]==0)
                {
                    

                    findway();
                    if (thereisway)
                    {
                        circulefield.Children.RemoveAt(ballchidindex);
                        this.gamemass[ballx][bally] = 0;
                        addbals(1, 1);
                        this.gamemass[fieldx][fieldy] = curentballcolor;
                        this.indexbalmass[ballx][bally] = -1;
                    this.canpressball = false;
                    this.addingballs = 3;
                    if ( m * n- ballcount == 2)
                    {
                        this.addingballs = 2;
                    }
                    if ( m * n - ballcount == 1)
                    {
                        this.addingballs = 1;
                    }
                    
                    chekcolortoremovevertical();
                    chekcolorremovehorizontal();
                    if(balscleared==false)
                    {
                        addbals(addingballs, 0);
                    }
                    updatefield();

                        if(ballcount >= (m*n))
                        {
                            main_menu.Visibility = System.Windows.Visibility.Collapsed;
                            option_menu.Visibility = System.Windows.Visibility.Collapsed;
                            scorepanel.Visibility = System.Windows.Visibility.Collapsed;
                            fieldwin.Visibility = System.Windows.Visibility.Collapsed;
                            gameover.Visibility = System.Windows.Visibility.Visible;

                            gmovertext.Text = "Игра Окончена\nВаш счет:\n"+Convert.ToString(score1);

                        }


                    }
                    else 
                    {
                        MessageBox.Show("Путь заблокирован");
                    }
                }
            }
        }
        public void removeball(int indexz)
        {
            Ellipse bal = new Ellipse();
            circulefield.Children.RemoveAt(indexz);
            this.ballcount = ballcount - 1;
        }




        private void verticalslider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            int gg = Convert.ToInt32(verticalslider.Value);
            if (tb1 != null)
                tb1.Text = gg.ToString();
        }

        private void horizontalslider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            int gg = Convert.ToInt32(horizontalslider.Value);
            if (htb != null)
                htb.Text = gg.ToString();
        }

        private void back_main_menu(object sender, RoutedEventArgs e)
        {
            if (gamestatus == 0)
            {
                scorepanel.Visibility = System.Windows.Visibility.Collapsed;
                fieldwin.Visibility = System.Windows.Visibility.Collapsed;
                option_menu.Visibility = System.Windows.Visibility.Collapsed;
                gameover.Visibility = System.Windows.Visibility.Collapsed;
                main_menu.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
             var result = MessageBox.Show("хотите закончить игру ?"," ",MessageBoxButton.YesNo,MessageBoxImage.Question);
             if (result == MessageBoxResult.Yes )
                {
                    gamestatus = 0;
                    field g = new field(field1);
                    field c = new field(circulefield);
                    g.resetfield();
                    c.resetfield();
                   scorepanel.Visibility = System.Windows.Visibility.Collapsed;
                   fieldwin.Visibility = System.Windows.Visibility.Collapsed;
                   option_menu.Visibility = System.Windows.Visibility.Collapsed;
                   gameover.Visibility = System.Windows.Visibility.Collapsed;
                   main_menu.Visibility = System.Windows.Visibility.Visible;

               }
                
            }
            
        }





        public int[][] mass { get; set; }
    }
}
