﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace ind_zad_lines_test
{
    class field
    {

        public ColumnDefinition col;//строка
        public RowDefinition row;//столбец
        public int n1, m1;//размер поля
        public int ballcounter=0;
        public int empthyfieldcount;
        public Grid maingrid { set; get; }
        public DockPanel fieldsize { set; get; }
        public int[][] gamemass;
        public int ballinmas ;//номер шарика в массиве в соответствии с цветом
        public Ellipse movingball { set; get; }
        public int ballx = 0;
        public int bally = 0;//место шарика
        public int fieldx, fieldy;//куда переместить шарик
        public int move { set; get; }







        //для создания полей и шаров
        
         public field(int x , int y , Grid g , DockPanel d , int mv)
        {

             n1 = x; m1 = y;
             maingrid = g; 
             fieldsize = d;
             empthyfieldcount = x * y;
             gamemass = new int[n1][];
             for (int i = 0; i < n1; i++)
             {
                 gamemass[i] = new int[m1];
             }
             for (int i = 0; i < n1; i++)
             {
                 for (int j = 0; j < m1; j++)
                 {
                     gamemass[i][j] = 0;
                 }
             }
             

         }
        // для перезапуска игры и расчистки полей
        public field(Grid g)
         {

             maingrid = g;
         }

        //для передачи статуса  чтобы сделать ход 1 выбор мяча 2 выбор поля
        public field(int n)
        {

            move = n; 
        }


        public void resetfield()
         {
             maingrid.Children.Clear();
             maingrid.ColumnDefinitions.Clear();
             maingrid.RowDefinitions.Clear();

         }

        

        public void addrowsandcol()
         {

            int n = n1;
            int m = m1;
            Thickness th = new Thickness(5);
            fieldsize.Margin = th;
            fieldsize.Height = m * 30;
            fieldsize.Width = n * 30;
            fieldsize.Visibility = Visibility.Visible;
            maingrid.Height = 30 * m;
            maingrid.Width = 30 * n;
             for (int i = 0; i < n; i++)
             {
                 
                 col = new ColumnDefinition();
                 GridLength len = new GridLength(30);
                 col.Width = len;
                 maingrid.ColumnDefinitions.Add(col);
                 
             }
             for (int i = 0; i < m; i++)
             {
                 row = new RowDefinition();
                 maingrid.RowDefinitions.Add(row);
       
             }
             
         }
       

        public void addbuttons()
        {

            int n = n1;
            int m = m1;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Rectangle b = new Rectangle();
                    b.Fill = new SolidColorBrush(Colors.Gray);
                    Thickness th = new Thickness(1);
                    b.Margin = th;
                    /*b.MouseLeftButtonDown += new MouseButtonEventHandler(selectrectangle);*/
                    
                    Grid.SetRow(b, j);
                    Grid.SetColumn(b, i);
                    maingrid.Children.Add(b);
                    
                    

                }

            }


            
        }
        public void addballs(int addingbals)
        {

            
            if (ballcounter < m1*n1)
            {
                if (empthyfieldcount == 2)
                    addingbals = 2;
                if (empthyfieldcount == 1)
                    addingbals = 1;
            int ballcount = 0;
            int n;//размер поля
            int m;//размер поля
            int xx;// для цветов массива
            
            Random celsrand = new Random();
            Random rand = new Random();
            
            while(ballcount < addingbals )
            {
                Ellipse ball = new Ellipse();
                Thickness th = new Thickness(4);
                ball.Margin = th; 
                n = celsrand.Next(0, n1 );
                m = celsrand.Next(0, m1 );
                Grid.SetColumn(ball, n);
                Grid.SetRow(ball, m);
                 xx = rand.Next(1, 7);
                 if (xx == 1)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Red);
                            ballinmas = 1;
                        }

                        if (xx == 2) 
                        {
                            ball.Fill = new SolidColorBrush(Colors.Orange);
                            ballinmas = 2;
                        }

                        if (xx == 3)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Yellow);
                            ballinmas = 3;
                        }
                        if (xx == 4)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Green);
                            ballinmas = 4;
                        }
                        if (xx == 5) 
                        {
                            ball.Fill = new SolidColorBrush(Colors.Aqua);
                            ballinmas = 5;
                        }

                        if (xx == 6)
                        {
                            ball.Fill = new SolidColorBrush(Colors.Purple);
                            ballinmas = 6;
                        }

                        if (xx == 7) 
                        {
                            ball.Fill = new SolidColorBrush(Colors.Blue);
                            ballinmas = 7;
                        }
                        if (maingrid.Children.Contains(ball) == false && gamemass[n][m]== 0 && ballinmas != -1)
                        {
                            EventArgs e = new EventArgs();
                            object sender = new object();
                            
                            /*ball.MouseLeftButtonDown += new MouseButtonEventHandler(selecevent);*/
                            
                            gamemass[n][m] = ballinmas;
                            maingrid.Children.Add(ball);
                ballcount++;
                 ballcounter++;
                empthyfieldcount--;
                        }
                            
                    }   
            }
            }
        public int get_ballcount()
        { return ballcounter; }

        public void game_over()
        {
            maingrid.Background = Brushes.Red;
            int n = n1;
            int m = m1;
            Thickness th = new Thickness(10);
            fieldsize.Margin = th;
            fieldsize.Height = 550;
            fieldsize.Width = 525;
            fieldsize.Visibility = Visibility.Visible;
            maingrid.Height = 550;
            maingrid.Width = 525;
        }
     /*   public void selecevent(object sender, EventArgs e)
        {
            

                Ellipse ball = (Ellipse)sender;
                
                
                
                if (mve.movestatus == 1)
                {
                    curentbal.balx = Grid.GetColumn(ball);
                    curentbal.baly = Grid.GetRow(ball);
                    curentbal.ballcolor = gamemass[Grid.GetColumn(ball)][Grid.GetRow(ball)];
                    ball.Fill = new SolidColorBrush(Colors.Black);
                    mve.changemove(mve.movestatus);
                }




        }*/

        public void selectrectangle(object sender, EventArgs e)
        {
            Rectangle f = (Rectangle)sender;

        
        }




        ~field()
        {}

    }
}
